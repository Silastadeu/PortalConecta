-- Execute no SQL Editor do Supabase. Crie os usuários em Authentication > Users.
create table if not exists public.chamados (
  id uuid primary key default gen_random_uuid(),
  titulo text not null check (char_length(titulo) between 3 and 120),
  descricao text check (char_length(descricao) <= 2000),
  categoria text not null default 'rede' check (categoria in ('rede','cftv','automacao','software','outro')),
  prioridade text not null default 'media' check (prioridade in ('baixa','media','alta')),
  status text not null default 'aberto' check (status in ('aberto','em_andamento','resolvido')),
  criado_por uuid not null default auth.uid() references auth.users(id),
  criado_em timestamptz not null default now()
);
create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  nome text not null check (char_length(nome) between 2 and 120),
  email text not null check (char_length(email) <= 200),
  mensagem text not null check (char_length(mensagem) between 5 and 2000),
  criado_em timestamptz not null default now()
);
alter table public.chamados enable row level security;
alter table public.leads enable row level security;
create policy "chamados_ler" on public.chamados for select to authenticated using (true);
create policy "chamados_criar" on public.chamados for insert to authenticated with check (criado_por = auth.uid());
create policy "leads_enviar" on public.leads for insert to anon, authenticated with check (true);
-- Leads só são lidos pelo painel do Supabase (nenhuma policy de select).
