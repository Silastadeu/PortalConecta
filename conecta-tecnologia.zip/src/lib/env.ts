import { z } from "zod";

const schema = z.object({
  NEXT_PUBLIC_SUPABASE_URL: z.url(),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().min(1),
  UNIFI_API_KEY: z.string().min(1).optional(),
});

/** Validação lazy: falha com mensagem clara em runtime, não derruba o build. */
export function getEnv() {
  const parsed = schema.safeParse({
    NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL,
    NEXT_PUBLIC_SUPABASE_ANON_KEY: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    UNIFI_API_KEY: process.env.UNIFI_API_KEY || undefined,
  });
  if (!parsed.success) {
    throw new Error("Variáveis de ambiente inválidas: " + parsed.error.issues.map((i) => i.path.join(".")).join(", "));
  }
  return parsed.data;
}
