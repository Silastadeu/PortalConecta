import { getEnv } from "@/lib/env";

export type Ativo = { id: string; nome: string; modelo: string; ip: string; online: boolean };
export type UnifiResult = { ok: true; ativos: Ativo[] } | { ok: false; motivo: string };

/** Site Manager API da UniFi (api.ui.com). Valide o formato com a sua chave real. */
export async function listarAtivos(): Promise<UnifiResult> {
  const key = getEnv().UNIFI_API_KEY;
  if (!key) return { ok: false, motivo: "UNIFI_API_KEY não configurada." };
  try {
    const res = await fetch("https://api.ui.com/v1/devices", {
      headers: { "X-API-KEY": key, Accept: "application/json" },
      next: { revalidate: 60 },
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return { ok: false, motivo: `UniFi respondeu ${res.status}.` };
    const json = (await res.json()) as { data?: { devices?: Record<string, unknown>[] }[] };
    const ativos = (json.data ?? []).flatMap((h) => h.devices ?? []).map((d, i): Ativo => ({
      id: String(d.id ?? d.mac ?? i),
      nome: String(d.name ?? d.hostname ?? "—"),
      modelo: String(d.model ?? d.shortname ?? "—"),
      ip: String(d.ip ?? "—"),
      online: String(d.status ?? "").toLowerCase() === "online",
    }));
    return { ok: true, ativos };
  } catch {
    return { ok: false, motivo: "Falha ao consultar a UniFi (timeout ou rede)." };
  }
}
