import { abrirChamado, sair } from "@/app/actions";
import { createClient } from "@/lib/supabase/server";
import { listarAtivos } from "@/lib/unifi";

export const dynamic = "force-dynamic";

const prio: Record<string, string> = { alta: "text-bad", media: "text-warn", baixa: "text-muted" };

export default async function Portal({ searchParams }: { searchParams: Promise<{ erro?: string }> }) {
  const { erro } = await searchParams;
  const supabase = await createClient();
  const [{ data: chamados }, unifi] = await Promise.all([
    supabase.from("chamados").select("id,titulo,categoria,prioridade,status,criado_em").order("criado_em", { ascending: false }).limit(20),
    listarAtivos(),
  ]);
  const abertos = (chamados ?? []).filter((c) => c.status !== "resolvido").length;
  const online = unifi.ok ? unifi.ativos.filter((a) => a.online).length : null;

  return (
    <main className="mx-auto max-w-6xl space-y-6 px-6 py-8">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-semibold tracking-tight">Conecta<span className="text-accent">NOC</span></h1>
        <form action={sair}><button className="btn-ghost" type="submit">Sair</button></form>
      </header>

      <section className="grid gap-4 sm:grid-cols-3">
        <div className="card"><p className="text-sm text-muted">Ativos online</p><p className="mt-1 font-mono text-3xl text-ok">{unifi.ok ? `${online}/${unifi.ativos.length}` : "—"}</p></div>
        <div className="card"><p className="text-sm text-muted">Chamados abertos</p><p className="mt-1 font-mono text-3xl text-warn">{abertos}</p></div>
        <div className="card"><p className="text-sm text-muted">Integração UniFi</p><p className={`mt-1 font-mono text-lg ${unifi.ok ? "text-ok" : "text-bad"}`}>{unifi.ok ? "Conectada" : unifi.motivo}</p></div>
      </section>

      <section className="card overflow-x-auto">
        <h2 className="mb-3 text-lg font-semibold">Inventário de ativos</h2>
        <table className="w-full text-sm">
          <thead><tr className="text-left text-muted"><th className="p-2">Ativo</th><th className="p-2">Modelo</th><th className="p-2">IP</th><th className="p-2">Status</th></tr></thead>
          <tbody>
            {unifi.ok && unifi.ativos.map((a) => (
              <tr key={a.id} className="border-t border-line"><td className="p-2">{a.nome}</td><td className="p-2">{a.modelo}</td><td className="p-2 font-mono">{a.ip}</td><td className={`p-2 ${a.online ? "text-ok" : "text-bad"}`}>{a.online ? "Online" : "Offline"}</td></tr>
            ))}
          </tbody>
        </table>
      </section>

      <section className="grid gap-6 lg:grid-cols-2">
        <div className="card overflow-x-auto">
          <h2 className="mb-3 text-lg font-semibold">Chamados</h2>
          <table className="w-full text-sm">
            <thead><tr className="text-left text-muted"><th className="p-2">Título</th><th className="p-2">Categoria</th><th className="p-2">Prioridade</th><th className="p-2">Status</th></tr></thead>
            <tbody>
              {(chamados ?? []).map((c) => (
                <tr key={c.id} className="border-t border-line"><td className="p-2">{c.titulo}</td><td className="p-2">{c.categoria}</td><td className={`p-2 ${prio[c.prioridade]}`}>{c.prioridade}</td><td className="p-2">{c.status.replace("_", " ")}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
        <form action={abrirChamado} className="card space-y-3">
          <h2 className="text-lg font-semibold">Abrir chamado</h2>
          {erro && <p role="alert" className="text-sm text-bad">Não foi possível abrir o chamado. Revise os campos.</p>}
          <div><label className="lbl" htmlFor="titulo">Título</label><input id="titulo" name="titulo" required minLength={3} maxLength={120} className="field" /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="lbl" htmlFor="categoria">Categoria</label><select id="categoria" name="categoria" className="field"><option value="rede">Rede</option><option value="cftv">CFTV</option><option value="automacao">Automação</option><option value="software">Software</option><option value="outro">Outro</option></select></div>
            <div><label className="lbl" htmlFor="prioridade">Prioridade</label><select id="prioridade" name="prioridade" defaultValue="media" className="field"><option value="baixa">Baixa</option><option value="media">Média</option><option value="alta">Alta</option></select></div>
          </div>
          <div><label className="lbl" htmlFor="descricao">Descrição</label><textarea id="descricao" name="descricao" rows={3} maxLength={2000} className="field" /></div>
          <button className="btn" type="submit">Enviar chamado</button>
        </form>
      </section>
    </main>
  );
}
