import { NextResponse } from "next/server";
import { listarAtivos } from "@/lib/unifi";

export async function GET() {
  const r = await listarAtivos();
  return NextResponse.json(r, { status: r.ok ? 200 : 502 });
}
