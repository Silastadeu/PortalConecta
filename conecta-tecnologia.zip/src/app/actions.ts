"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";

const lead = z.object({
  nome: z.string().trim().min(2).max(120),
  email: z.email().max(200),
  mensagem: z.string().trim().min(5).max(2000),
});

export async function enviarContato(formData: FormData) {
  if (formData.get("site")) redirect("/?enviado=1#contato"); // honeypot
  const parsed = lead.safeParse(Object.fromEntries(formData));
  if (!parsed.success) redirect("/?erro=1#contato");
  const supabase = await createClient();
  const { error } = await supabase.from("leads").insert(parsed.data);
  redirect(error ? "/?erro=1#contato" : "/?enviado=1#contato");
}

const chamado = z.object({
  titulo: z.string().trim().min(3).max(120),
  descricao: z.string().trim().max(2000).optional(),
  categoria: z.enum(["rede", "cftv", "automacao", "software", "outro"]),
  prioridade: z.enum(["baixa", "media", "alta"]),
});

export async function abrirChamado(formData: FormData) {
  const parsed = chamado.safeParse(Object.fromEntries(formData));
  if (!parsed.success) redirect("/portal?erro=1");
  const supabase = await createClient();
  const { error } = await supabase.from("chamados").insert(parsed.data);
  if (error) redirect("/portal?erro=1");
  revalidatePath("/portal");
  redirect("/portal");
}

export async function entrar(formData: FormData) {
  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({
    email: String(formData.get("email") ?? ""),
    password: String(formData.get("senha") ?? ""),
  });
  redirect(error ? "/login?erro=1" : "/portal");
}

export async function sair() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/");
}
