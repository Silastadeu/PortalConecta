import Link from "next/link";
import { enviarContato } from "@/app/actions";

const servicos = [
  ["Infraestrutura de rede UniFi", "Projeto, cabeamento, Wi-Fi e switching com gestão centralizada e telemetria."],
  ["CFTV Intelbras", "Câmeras, gravação e acesso remoto dimensionados para a sua operação."],
  ["Visão computacional Vession AI", "Deep learning aplicado a vídeo para detecção e alertas em tempo real."],
  ["Automação e CLP", "Integração de linhas de produção, CLPs e sistemas de gestão operacional."],
  ["Software sob medida", "ERP, APIs e integrações com UniFi e telemetria feitos para o seu processo."],
  ["Engenharia MSP 24/7", "Monitoramento contínuo, chamados com SLA e contingência."],
];

export default async function Home({ searchParams }: { searchParams: Promise<{ enviado?: string; erro?: string }> }) {
  const { enviado, erro } = await searchParams;
  return (
    <>
      <header className="border-b border-line">
        <div className="mx-auto flex min-h-18 max-w-6xl flex-wrap items-center justify-between gap-3 px-6">
          <strong className="text-lg tracking-tight">Conecta<span className="text-accent">Tecnologia</span></strong>
          <nav className="flex gap-7 text-sm text-[#c5d0e3]"><a href="#servicos">Serviços</a><a href="#msp">Contratos MSP</a><a href="#contato">Contato</a></nav>
          <Link href="/login" className="btn-ghost">Portal do cliente</Link>
        </div>
      </header>

      <main>
        <section className="mx-auto max-w-6xl px-6 py-24">
          <p className="font-mono text-xs uppercase tracking-[0.12em] text-accent">Engenharia · MSP · Automação</p>
          <h1 className="mt-5 max-w-3xl text-5xl font-bold leading-[1.08] tracking-tight">Rede, segurança e automação operadas por quem projeta.</h1>
          <p className="mt-6 max-w-2xl text-lg text-muted">Projetamos, implantamos e monitoramos redes UniFi, CFTV Intelbras, visão computacional com Vession AI e automação industrial, com NOC em Sorocaba e contrato MSP.</p>
          <div className="mt-8 flex flex-wrap gap-3"><a href="#contato" className="btn">Solicitar diagnóstico</a><a href="#msp" className="btn-ghost">Conhecer o portal NOC</a></div>
        </section>

        <section id="servicos" className="mx-auto max-w-6xl px-6 pb-24">
          <h2 className="mb-10 text-3xl font-semibold tracking-tight">O que entregamos</h2>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {servicos.map(([t, d]) => (<div key={t} className="card"><h3 className="text-lg font-semibold">{t}</h3><p className="mt-2 text-muted">{d}</p></div>))}
          </div>
        </section>

        <section id="msp" className="border-y border-line bg-[#0e1626] py-24">
          <div className="mx-auto max-w-6xl px-6">
            <h2 className="max-w-2xl text-3xl font-semibold tracking-tight">Sua planta monitorada em tempo real no portal do cliente</h2>
            <p className="mt-4 max-w-2xl text-muted">Topologia, inventário de ativos, disponibilidade e chamados técnicos em um só lugar.</p>
            <Link href="/login" className="btn mt-8">Acessar o portal</Link>
          </div>
        </section>

        <section id="contato" className="mx-auto max-w-2xl px-6 py-24">
          <h2 className="text-3xl font-semibold tracking-tight">Diagnóstico técnico</h2>
          <p className="mb-8 mt-2 text-muted">Conte o cenário e retornamos com uma proposta.</p>
          {enviado && <p role="status" className="mb-4 text-ok">Recebido! Entraremos em contato em breve.</p>}
          {erro && <p role="alert" className="mb-4 text-bad">Não foi possível enviar. Revise os campos e tente novamente.</p>}
          <form action={enviarContato} className="card space-y-4">
            <input name="site" tabIndex={-1} autoComplete="off" aria-hidden="true" className="hidden" />
            <div><label className="lbl" htmlFor="nome">Nome</label><input id="nome" name="nome" required minLength={2} className="field" /></div>
            <div><label className="lbl" htmlFor="email">E-mail</label><input id="email" name="email" type="email" required className="field" /></div>
            <div><label className="lbl" htmlFor="mensagem">Necessidade</label><textarea id="mensagem" name="mensagem" rows={4} required minLength={5} className="field" /></div>
            <button className="btn" type="submit">Enviar solicitação</button>
          </form>
        </section>
      </main>

      <footer className="border-t border-line py-7 text-sm text-muted"><div className="mx-auto flex max-w-6xl flex-wrap justify-between gap-2 px-6"><span>Conecta Tecnologia · conectatecnologia.tec.br</span><span>Atendimento NOC 24/7 para clientes MSP</span></div></footer>
    </>
  );
}
