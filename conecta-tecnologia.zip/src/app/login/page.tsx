import { entrar } from "@/app/actions";

export default async function Login({ searchParams }: { searchParams: Promise<{ erro?: string }> }) {
  const { erro } = await searchParams;
  return (
    <main className="mx-auto flex min-h-screen max-w-md items-center px-6">
      <form action={entrar} className="card w-full space-y-4">
        <h1 className="text-2xl font-semibold tracking-tight">Portal do cliente</h1>
        {erro && <p role="alert" className="text-sm text-bad">E-mail ou senha inválidos.</p>}
        <div><label className="lbl" htmlFor="email">E-mail</label><input id="email" name="email" type="email" required autoComplete="email" className="field" /></div>
        <div><label className="lbl" htmlFor="senha">Senha</label><input id="senha" name="senha" type="password" required autoComplete="current-password" className="field" /></div>
        <button className="btn" type="submit">Entrar</button>
      </form>
    </main>
  );
}
