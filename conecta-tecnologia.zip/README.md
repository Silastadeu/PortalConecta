# Conecta Tecnologia

Next.js (App Router) + Supabase + API UniFi. Site institucional e portal NOC com login.

## Subir
1. Supabase: rode `supabase/schema.sql` no SQL Editor e crie os usuários em Authentication.
2. `cp .env.example .env.local` e preencha.
3. `npm install && npm run dev`.

## Vercel
Um único projeto. Em Settings > Environment Variables cadastre as variáveis do `.env.example`
(`UNIFI_API_KEY` sem prefixo `NEXT_PUBLIC_`). Node 20+.

## Segurança
- `/portal` e `/api/unifi` exigem sessão (`src/proxy.ts`).
- RLS ativo; só `leads` aceita insert anônimo (formulário do site, com honeypot).
- Nenhuma chave de serviço no código. Para vários clientes MSP, adicione `organizacao_id` e filtre nas policies.
